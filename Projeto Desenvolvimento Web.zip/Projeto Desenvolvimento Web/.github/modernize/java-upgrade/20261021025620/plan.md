Get-ChildItem "C:\Program Files\Java" -ErrorAction SilentlyContinue# Upgrade Plan: dados-pessoais (20261021025620)

- **Generated**: 2026-10-20 23:57 -03:00
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 17: not available (baseline will be skipped)
- JDK 25.0.1: `C:\Users\W11\.jdks\openjdk-25.0.1` (target JDK, used for upgrade and final validation)

**Build Tools**
- Maven 3.10.0: Maven Wrapper distribution configured in `.mvn/wrapper/maven-wrapper.properties` (used by `mvnw.cmd`)
- Maven 3.9.15: `C:\Users\W11\.maven\maven-3.9.15\bin` (installed, not required; wrapper is preferred)

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: N/A (this workspace is not a Git repository; changes will not be version-controlled)
- Run tests before and after the upgrade: true

## Upgrade Goals

- Java runtime/compiler target: 25 (latest LTS)

## Technology Stack

| Technology/Dependency | Current | Min Compatible Version | Why Incompatible |
| --------------------- | ------- | ---------------------- | ---------------- |
| Java | 17 | 25 | User requested Java 25 LTS |
| Spring Boot | 4.1.1 | 4.1.1 | Already supports the application's modern Java baseline; no framework upgrade needed |
| Maven Wrapper | 3.10.0 | 3.10.0 | Existing wrapper is sufficient for Java 25 |
| spring-boot-maven-plugin | Managed by Spring Boot 4.1.1 | Managed by Spring Boot 4.1.1 | No plugin change required |

## Derived Upgrades

- Update the Maven `java.version` property to 25 so Spring Boot's managed compiler configuration targets Java 25.
- No build-tool, framework, Kotlin, Jakarta, source-code, runtime configuration, or CI upgrades are indicated by the files found in this project.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
| ---- | ---------- | ------- | ------ | ------ | ------ |
| None | No dependency version changes required | N/A | N/A | N/A | Existing Spring Boot and Maven Wrapper versions need no change for this Java target |

### Source Code Changes

| File | Location | Current | Required Change | Reason |
| ---- | -------- | ------- | --------------- | ------ |
| None | Application and test sources | No Java-version-specific incompatibilities found | None | Java 25 target change does not require source changes in the inspected files |

### Configuration Changes

| File | Property/Setting | Current | Required Change | Reason |
| ---- | ---------------- | ------- | --------------- | ------ |
| `pom.xml` | `properties/java.version` | `17` | Set to `25` | Set the compiler/runtime target to the requested Java LTS |

### CI/CD Changes

No CI/CD, Docker, or pipeline files with Java-version declarations were found.

### Risks & Warnings

- **Baseline unavailable**: JDK 17 is not installed, so a pre-upgrade build/test baseline cannot be measured. **Mitigation**: Build and run all tests on the installed JDK 25 after the POM change.
- **Workspace has no Git metadata**: Changes cannot be recorded in a branch or commit. **Mitigation**: Leave changes in the working tree and record validation results in this session's progress and summary artifacts.
- **Runtime compatibility is not fully characterized by a context-load test**: The existing test suite contains a Spring context-load test only. **Mitigation**: Run the complete project test suite and report its measured result; no Java 25-specific reflection or internal API usage was found in the source files.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Confirm the required target JDK and build tooling are available before making changes.
  - **Changes to Make**: No project file changes; use the installed JDK 25 and Maven Wrapper.
  - **Verification**: List installed JDKs; confirm JDK 25.0.1. No installation is required.
- Step 2: Setup Baseline
  - **Rationale**: Capture pre-upgrade behavior when the current JDK is available.
  - **Changes to Make**: None.
  - **Verification**: Skipped because JDK 17 is not installed.
- Step 3: Target Java 25
  - **Rationale**: Apply the requested runtime/compiler target using the existing Spring Boot-managed compiler setup.
  - **Changes to Make**: Apply the `pom.xml` configuration change in Impact Analysis.
  - **Verification**: `.\mvnw.cmd clean test-compile -q` using JDK 25; expected result is successful compilation of production and test sources.
- Step 4: CVE Validation
  - **Rationale**: Check the resolved direct dependency set for known vulnerabilities after the target change.
  - **Changes to Make**: Upgrade direct dependency versions only if the scan identifies a fix required for this project.
  - **Verification**: Scan resolved direct dependencies, compile after any remediation, and rescan.
- Step 5: Final Validation
  - **Rationale**: Verify the requested target and run the complete test suite on the target JDK.
  - **Changes to Make**: Resolve any failures caused by the Java 25 change.
  - **Verification**: `.\mvnw.cmd clean test -q` using JDK 25; expected result is successful build and 100% passing tests.
