package br.senac.tads.dns.dados_pessoais.repositorio;

import java.util.List;
import java.util.Optional;
//na etapa 5 ocorre a 
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


// Esta interface é o meu acesso ao banco para a tabela tb_pessoas.
// Eu não escrevo a implementação: o Spring Data JPA cria sozinho
// quando a aplicação sobe.
//
// @Repository: avisa o Spring que isto é um repositório (camada de acesso
// a dados), para ele gerenciar e poder entregar para os services.

import br.senac.tads.dns.dados_pessoais.entidade.PessoaEntity;

// @Repository indica que a interface é um repositório Spring Data JPA;
// o Spring gera a implementação dos métodos de acesso ao banco.
@Repository
public interface PessoaRepository extends JpaRepository<PessoaEntity, Integer> {
// JpaRepository<PessoaEntity, Integer>:
//   - PessoaEntity: a entidade que este repositório manipula.
//   - Integer: o tipo do id (chave primária) dela.
// Só de estender, já ganho métodos prontos: save, findAll, findById,
// delete, count, etc. Por isso não precisei escrever nenhum SQL para
// o DataInitializer salvar as pessoas.


    // O Spring Data JPA gera a query a partir do nome do método:
    // SELECT * FROM tb_pessoas WHERE username = :username
    Optional<PessoaEntity> findByUsername(String username);

    // Gera: SELECT COUNT(*) > 0 FROM tb_pessoas WHERE username = :username
    boolean existsByUsername(String username);

// CONSULTA ESCRITA POR MIM (JPQL): usei @Query porque o nome do método
    // ficaria grande demais para o Spring derivar sozinho.
    // JPQL é parecido com SQL, mas usa os nomes da CLASSE Java (PessoaEntity)
    // e dos CAMPOS (p.username), e não os da tabela e das colunas.
    //
    // Explicando a consulta:
    //   - LOWER(...): deixa tudo minúsculo, para não diferenciar maiúscula
    //     de minúscula ("Java" acha "java").
    //   - LIKE '%termo%': o % significa "qualquer coisa antes ou depois",
    //     então procura o texto em qualquer parte do campo.
    //   - OR: basta o termo aparecer no username, no nome OU no e-mail.
    //
    // As três aspas (""") abrem e fecham um bloco de texto do Java, que
    // permite escrever a consulta em várias linhas.


    // Versão JPQL: opera sobre os campos da entidade Java (não sobre colunas SQL)
   
    // @Param("termo"): liga o parâmetro do método ao ":termo" da consulta.
    // Passar o valor por parâmetro (e não colar o texto na consulta) também
    // protege contra SQL injection.
    @Query("""
            SELECT p FROM PessoaEntity p
            WHERE LOWER(p.username) LIKE LOWER(CONCAT('%', :termo, '%'))
               OR LOWER(p.nome)     LIKE LOWER(CONCAT('%', :termo, '%'))
               OR LOWER(p.email)    LIKE LOWER(CONCAT('%', :termo, '%'))
            """)
    List<PessoaEntity> buscarPorTermo(@Param("termo") String termo);
}