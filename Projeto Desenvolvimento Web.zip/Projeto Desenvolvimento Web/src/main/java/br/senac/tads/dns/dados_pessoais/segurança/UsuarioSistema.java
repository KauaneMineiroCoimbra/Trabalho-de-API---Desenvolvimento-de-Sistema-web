package br.senac.tads.dns.dados_pessoais.segurança;

import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

// Representa um usuário no contexto do Spring Security.
// UserDetails é a interface padrão que o framework usa para carregar e inspecionar usuários.
// Ao implementá-la, esta classe "fala a língua" do Spring Security.

// A.4: define a ordem dos campos no JSON retornado por /me
@JsonPropertyOrder({ "username", "senhaCodificada", "roles" })
public class UsuarioSistema implements UserDetails {

    private final String username;
    private final String password;
    private final List<GrantedAuthority> authorities;

    public UsuarioSistema(String username, String password, List<GrantedAuthority> authorities) {
        this.username = username;
        this.password = password; // Senha já codificada pelo PasswordEncoder
        this.authorities = authorities; // Permissões do usuário (ex: ROLE_ADMIN)
    }

    @Override
    public String getUsername() { return username; }

    // A.4: no JSON, "password" aparece como "senhaCodificada"
    @Override
    @JsonProperty("senhaCodificada")
    public String getPassword() { return password; }

    // getAuthorities() retorna a lista de permissões (roles) do usuário.
    // A.4: @JsonIgnore tira do JSON o formato [{"authority": "..."}].
    // O Spring Security continua usando este método normalmente.
    @Override
    @JsonIgnore
    public Collection<? extends GrantedAuthority> getAuthorities() { return authorities; }

    // A.4: getter customizado que gera "roles": ["ROLE_ADMIN", ...] (lista de Strings)
    @JsonProperty("roles")
    public List<String> getRoles() {
        return authorities.stream().map(GrantedAuthority::getAuthority).toList();
    }

    // Os quatro métodos abaixo controlam o estado da conta.
    // A.4: @JsonIgnore para não aparecerem no JSON.
    @Override @JsonIgnore public boolean isAccountNonExpired() { return true; }
    @Override @JsonIgnore public boolean isAccountNonLocked() { return true; }
    @Override @JsonIgnore public boolean isCredentialsNonExpired() { return true; }
    @Override @JsonIgnore public boolean isEnabled() { return true; }
}
