package br.senac.tads.dns.validacao;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
// o lang do java é usado para importar as classes de anotação do Java, 
// jakarta.validation é usado para importar as classes.
//retentition é usado para definir o tempo de vida da anotação, que neste caso é RUNTIME, ou seja, anotacao esta disponivel.

import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
// o target é usado para definir onde a anotação pode ser aplicada, que neste caso é TYPE, ou seja, em classes e interfaces.
import jakarta.validation.Constraint;
import jakarta.validation.Payload;
// o payload define informacao adicional associando a anotacao com o tipo de cargo
@Documented
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = SenhasIguaisValidator.class)
public @interface SenhasIguais {

    String message() default "A senha e repetição devem ser iguais";
// o groups e um atributo que define grupos de validação, que podem ser usados para agrupar e categorizar as validações aplicadas às classes e campos.
    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
// o groups e o payload são usados para definir grupos de validação e informações adicionais associadas à anotação, respectivamente. 
//  usados pelo framework de validação para agrupar e categorizar as validações aplicadas às classes e campos.

//com o extends e feito o relacionamento entre a anotacao e o validador.
// a classe SenhasIguaisValidator, que implementa a lógica de validação da anotação @SenhasIguais com o  objetivo de validar se as senhas informadas em um objeto Pessoa são iguais.