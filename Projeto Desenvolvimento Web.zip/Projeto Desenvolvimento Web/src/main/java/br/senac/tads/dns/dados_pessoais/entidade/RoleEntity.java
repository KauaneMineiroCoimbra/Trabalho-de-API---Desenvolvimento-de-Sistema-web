package br.senac.tads.dns.dados_pessoais.entidade;
//na etapa 7 a cricao do role entity foi criada para representar as roles do sistema, com os atributos id e nome. Adicionou as anotações JPA ( @Entity , @Table , @Id , etc.) à classe RoleEntity
//usado para indicar que a classe RoleEntity é uma entidade JPA, que será mapeada para uma tabela no banco de dados. O table é usado para definir o nome da tabela como tb_roles. O id é usado para indicar que o atributo id é a chave primária da tabela, e o generatedvalue é usado para definir a estratégia de geração do valor do id como identity, ou seja, o banco de dados vai gerar automaticamente um valor único para cada registro inserido na tabela.

//utilizado que o contrutor sem argumentos é necessário para que o JPA possa criar instâncias da entidade RoleEntity quando estiver carregando dados do banco de dados. O JPA usa reflexão para instanciar objetos e precisa de um construtor público ou protegido sem argumentos para isso.

import jakarta.persistence.Column;
import jakarta.persistence.Entity;


import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

// Representa uma role do sistema (ex: "ROLE_ADMIN") na tabela tb_roles
@Entity
@Table(name = "tb_roles")
public class RoleEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, unique = true, length = 50)
    private String nome;

    // Construtor sem argumentos (obrigatório para o JPA)
    public RoleEntity() {
    }

    public RoleEntity(String nome) {
        this.nome = nome;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
}
