package br.senac.tads.dns.dados_pessoais.repositorio;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.senac.tads.dns.dados_pessoais.entidade.UsuarioSistemaEntity;

@Repository
public interface UsuarioSistemaRepository extends JpaRepository<UsuarioSistemaEntity, Integer> {

    // O Spring gera a consulta pelo nome do método:
    // SELECT * FROM tb_usuarios_sistema WHERE username = :username
    Optional<UsuarioSistemaEntity> findByUsername(String username);
}
