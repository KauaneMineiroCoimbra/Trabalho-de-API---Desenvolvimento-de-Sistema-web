package br.senac.tads.dns.dados_pessoais.segurança;

import java.util.List;
//feito na etapa 6 para implementar autenticação e autorização de usuários usando Spring Security.
//o SecurityConfig é responsável por configurar as regras de segurança da aplicação, como quais rotas exigem autenticação, quais são públicas, como tratar CORS, CSRF, sessões e filtros de autenticação.

import org.springframework.http.HttpStatus;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
//adicionando p etapa 7.3 para interceptar todas as requisições HTTP e verificar se o JWT (JSON Web Token) está presente e válido.
//criado na etapa 7.3 para interceptar todas as requisições HTTP e verificar se o JWT (JSON Web Token) está presente e válido.

import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
//criado na etapa 7.3 para a segurança da aplicação, permitindo definir regras de acesso por role diretamente nos métodos dos endpoints usando a anotação @PreAuthorize.
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
//na etapa 7.8 collocar essse import para usar o BCryptPasswordEncoder, que é mais seguro do que o NoOpPasswordEncoder.
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

@Configuration
//a configuração de segurança da aplicação é feita através da anotação @EnableWebSecurity, que habilita o Spring Security e permite personalizar as regras de segurança.
@EnableWebSecurity
@EnableMethodSecurity //habilita a anotação @PreAuthorize nos controllers, permitindo definir regras de acesso por role diretamente nos métodos dos endpoints.
public class SecurityConfig {
//na etapa 7 vamos trocar o NoOpPasswordEncoder por BCryptPasswordEncoder, que é mais seguro.
//ele e usado para autenticar usuários em uma aplicação Spring Boot, garantindo que apenas usuários autenticados possam acessar determinados recursos da API.
//feito na etapa 7.3, para interceptar todas as requisições HTTP e verificar se o JWT (JSON Web Token) está presente e válido.
	// 1) Injeção do JwtFilter (Etapa 7.3)
	private final JwtFilter jwtFilter;

	public SecurityConfig(JwtFilter jwtFilter) {
		this.jwtFilter = jwtFilter;
	}
//o bean usado para configurar o filtro de segurança da aplicação, definindo quais rotas são públicas, quais exigem autenticação, como tratar CORS, CSRF, sessões e filtros de autenticação.

	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		http
				// CORS configurado no Security, para o preflight OPTIONS passar pelos filtros
				.cors(cors -> cors.configurationSource(corsConfigurationSource()))

				// CSRF desnecessário em API stateless com JWT
				.csrf(csrf -> csrf.disable())

				// Permite frames (console H2)
				.headers(headers -> headers.frameOptions(frame -> frame.disable()))

				// Sem sessão HTTP: cada requisição traz seu JWT
				.sessionManagement(session -> session
						.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

				.authorizeHttpRequests(auth -> auth
						// Login público (só POST)
						.requestMatchers(HttpMethod.POST, "/login").permitAll()
						// Console H2 (REMOVER em produção)
						.requestMatchers("/h2-console/**").permitAll()
						// Swagger
						.requestMatchers("/swagger-ui.html", "/swagger-ui/**", "/v3/api-docs/**").permitAll()
						// Página de erro (evita mascarar erros reais com 401/403)
						.requestMatchers("/error").permitAll()

						// 2) Novas regras da Etapa 7.3
						// /me exige autenticação
						.requestMatchers("/me").authenticated()
						// Páginas estáticas (index.html, form.html, security.html)
						.requestMatchers("/", "/*.html", "/*.css", "/*.js").permitAll()

						// Anexo A.2: proteção do CRUD de pessoas
						// Leitura de pessoas: público
						.requestMatchers(HttpMethod.GET, "/pessoas", "/pessoas/**").permitAll()
						// Escrita exige autenticação (o @PreAuthorize no controller exige ROLE_ADMIN)
						.requestMatchers(HttpMethod.POST, "/pessoas", "/pessoas/**").authenticated()
						.requestMatchers(HttpMethod.PUT, "/pessoas/**").authenticated()
						.requestMatchers(HttpMethod.DELETE, "/pessoas/**").authenticated()

						// Demais rotas exigem token (MANTER COMO ÚLTIMA REGRA)
						.anyRequest().authenticated())

				// CORREÇÃO: sem autenticação, responde 401.
				// Como removemos o oauth2ResourceServer, o padrão do Spring passou a ser 403,
				// então definimos explicitamente o AuthenticationEntryPoint.
				.exceptionHandling(ex -> ex
						.authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED)))

				// 3) Registra o JwtFilter ANTES do filtro padrão de usuário/senha.
				// Fluxo: JwtFilter valida o token -> preenche o SecurityContextHolder
				// -> as regras de autorização enxergam o usuário autenticado.
				.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

		return http.build();
	}
//aqui ele atualiza a configuração de CORS, permitindo que o front-end (Angular) acesse a API (Spring Boot) de outro domínio.
//atyaliza na etapa 7 tb para incluir a configuração do CORS, que é necessária para permitir que o front-end (Angular) acesse a API (Spring Boot) de outro domínio.
	// Configuração de CORS (Anexo A.1 da Etapa 6)
	@Bean
	public CorsConfigurationSource corsConfigurationSource() {
		CorsConfiguration config = new CorsConfiguration();
		config.setAllowedOrigins(List.of("http://localhost:3000", "https://meu-frontend.com"));
		config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
		config.setAllowedHeaders(List.of("Authorization", "Content-Type"));

		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", config);
		return source;
	}

	// Executa a autenticação (UserDetailsService + PasswordEncoder)
	@Bean
	public AuthenticationManager authenticationManager(
			UserDetailsService userDetailsService,
			PasswordEncoder passwordEncoder) {
		DaoAuthenticationProvider provider = new DaoAuthenticationProvider(userDetailsService);
		provider.setPasswordEncoder(passwordEncoder);
		return new ProviderManager(provider);
	}

	// Etapa 7.8: senhas com hash BCrypt (salt aleatório embutido, algoritmo lento de propósito)
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
} 