package br.senac.tads.dns;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DadosPessoaisApplication {

	public static void main(String[] args) {
		SpringApplication.run(DadosPessoaisApplication.class, args);
	}

}


//aqui e onde o spring boot vai iniciar a aplicacao, que e a classe principal da aplicacao, que contem o metodo main,
//  que e o ponto de entrada da aplicacao. O SpringApplication.run() e usado para iniciar a aplicacao Spring Boot,
//  que vai configurar automaticamente o contexto da aplicacao, escanear os componentes, configurar o servidor web embutido
//  (como Tomcat ou Jetty) e iniciar a aplicacao.

//ele baixa junto com o spring e da o suporte e auxilio que inicia a aplicacao, que e o spring boot starter, que e um conjunto de dependencias 
// que facilitam a configuracao e o desenvolvimento da aplicacao. Ele inclui bibliotecas e configurações padrão para diversos recursos, como web, banco de dados, segurança, etc.