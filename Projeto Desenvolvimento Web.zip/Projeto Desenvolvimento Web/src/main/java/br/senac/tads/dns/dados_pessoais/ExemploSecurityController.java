package br.senac.tads.dns.dados_pessoais;
import br.senac.tads.dns.dados_pessoais.segurança.UsuarioSistema;

//na etapa 7 adiciona um novo import para a anotação @SecurityRequirement, que é usada para
// indicar ao Swagger que os endpoints precisam do token JWT
// Novo import a adicionar:
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
// Import a adicionar: na etapa 7.5 que adiciona a anotação @PreAuthorize, que é usada para definir regras de acesso por role diretamente nos métodos dos endpoints.
import org.springframework.security.access.prepost.PreAuthorize;


import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
//na etapa 7, vamos trocar o NoOpPasswordEncoder por BCryptPasswordEncoder, que é mais seguro.
//A ETAPA 7 também vai incluir a configuração do CORS, que é necessária para permitir que o front-end (Angular) acesse a API
@RestController

//etapa 7 criada a anotação @SecurityRequirement(name = "bearerJwt") para
@SecurityRequirement(name = "bearerJwt") // <==== ADICIONAR NA CLASSE EXISTENTE
public class ExemploSecurityController {

private final UserDetailsService userDetailsService;

// Injetamos o UserDetailsService para carregar o UsuarioSistema completo pelo username,
// já que o JwtFilter armazena apenas o username (String) no SecurityContextHolder.
public ExemploSecurityController(UserDetailsService userDetailsService) {
this.userDetailsService = userDetailsService;
}
// Acessível apenas para usuários autenticados.
// auth.getPrincipal() retorna o username (String) extraído do JWT pelo JwtFilter.
// O cast para UsuarioSistema é seguro: o UsuarioSistemaService sempre retorna
// instâncias desta classe concreta em loadUserByUsername().

// ATENÇÃO - abordagem exclusivamente didática:
// retornar diretamente a entidade de dominio expõe campos internos (hash da senha,
// flags de estado da conta) que não deveriam aparecer em uma API de produção.
// Em um sistema real, projete um DTO de resposta contendo apenas os dados necessários.
@GetMapping("/me")
public UsuarioSistema obterDadosUsuarioLogado(Authentication auth) {
String username = (String) auth.getPrincipal();
return (UsuarioSistema) userDetailsService.loadUserByUsername(username);

}

// ---- Etapa 7.5: endpoints de demonstração por role ----

// Record inline que representa a resposta dos endpoints de acesso por role.
// Records são classes de dados imutáveis introduzidas no Java 16:
// o compilador gera automaticamente construtor, getters, equals, hashCode e toString.
// Ao serializar para JSON, o Jackson usa os getters gerados: { "usuario": "...", "mensagem": "..." }
public record MensagemRoleDto(String usuario, String mensagem) {}

// Endpoint destinado apenas a usuários com ROLE_ADMIN.
// O controle de acesso real por role será adicionado no passo 7.6.
@PreAuthorize("hasRole('ADMIN')")       //adicionado na etapa 7.6 para restringir o acesso a este endpoint apenas para usuários com ROLE_ADMIN

@GetMapping("/acesso/admin")
public MensagemRoleDto mensagemAdmin(Authentication auth) {
return new MensagemRoleDto(
(String) auth.getPrincipal(),
"Mensagem para usuário com Role ADMIN"
);
}

// Endpoint destinado apenas a usuários com ROLE_GERENTE.
@PreAuthorize("hasRole('GERENTE')") //verifica se o usuário autenticado possui a role GERENTE antes de permitir o acesso ao endpoint.

@GetMapping("/acesso/gerente")
public MensagemRoleDto mensagemGerente(Authentication auth) {
return new MensagemRoleDto(
(String) auth.getPrincipal(),
"Mensagem para usuário com Role GERENTE"
);
}

// Endpoint destinado apenas a usuários com ROLE_USER.
@PreAuthorize("hasRole('USER')") 
@GetMapping("/acesso/user")
public MensagemRoleDto mensagemUser(Authentication auth) {
return new MensagemRoleDto(
(String) auth.getPrincipal(),
"Mensagem para usuário com Role USER"
);
}
}
