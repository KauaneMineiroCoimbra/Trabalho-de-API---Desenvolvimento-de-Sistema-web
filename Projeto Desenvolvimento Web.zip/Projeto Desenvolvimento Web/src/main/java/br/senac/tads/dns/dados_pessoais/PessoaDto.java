package br.senac.tads.dns.dados_pessoais;
// o import do time local/date e o import do list são usados para importar as classes LocalDate e List, que são usadas para representar a data
//  de nascimento e a lista de conhecimentos da pessoa, respectivamente quando vamos procurar alguem
import java.time.LocalDate;
import java.util.List;
// o not blank e um not null são usados para validar que os campos username, nome, email e dataNascimento não podem ser nulos ou vazios
//  enquanto o size é usado para validar o tamanho máximo dos campos username, nome, email e telefone.
import br.senac.tads.dns.validacao.SenhasIguais;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Size;

@SenhasIguais
public class PessoaDto {
    // na etapa 4 foi criado a classe Pessoa, que representa uma pessoa cadastrada no sistema, com os atributos id, username, nome, email, telefone, dataNascimento, senha, senhaRepeticao e conhecimentos.
    // o id e um atributo privado que representa o id da pessoa, enquanto os outros atributos são os campos de dados da pessoa.
    //Adicionou as anotações Bean Validation ( @NotBlank , 
    // @Email , @PastOrPresent , etc.) à classePessoa

//o private integer e um atributo privado que representa o id da pessoa, enquanto os outros atributos são os campos de dados da pessoa.
    private Integer id;

    @NotBlank(message = "O username é obrigatório")
    @Size(max = 64)
    private String username;

    @NotBlank(message = "O nome completo é obrigatório")
    @Size(max = 100)
    private String nome;

    @NotBlank
    @Size(max = 100)
    @Email
    private String email;

    @Size(max = 20)
    private String telefone;

    @NotNull
    @PastOrPresent
    private LocalDate dataNascimento;

    private String senha;

    private String senhaRepeticao;

    private List<String> conhecimentos;

    // Construtor vazio: exigido pelo Jackson para converter JSON em objeto
    public PessoaDto() {
    }

    // Construtor completo: facilita criar os dados iniciais no service
    public PessoaDto(Integer id, String username, String nome, String email,
            String telefone, LocalDate dataNascimento, String senha,
            String senhaRepeticao, List<String> conhecimentos) {
        this.id = id;
        this.username = username;
        this.nome = nome;
        this.email = email;
        this.telefone = telefone;
        this.dataNascimento = dataNascimento;
        this.senha = senha;
        this.senhaRepeticao = senhaRepeticao;
        this.conhecimentos = conhecimentos;
    }
// aqui começa os construtores e os getters e setters da classe Pessoa, que são usados para criar objetos Pessoa e acessar seus atributos.
//no souce action tem a opcao de gerar os getters e setters automaticamente, que são usados para acessar os atributos privados da classe Pessoa.
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getSenhaRepeticao() {
        return senhaRepeticao;
    }

    public void setSenhaRepeticao(String senhaRepeticao) {
        this.senhaRepeticao = senhaRepeticao;
    }

    public List<String> getConhecimentos() {
        return conhecimentos;
    }
// a list <string> assim e usada para representar uma lista de conhecimentos da pessoa, que são armazenados como strings. 
// O getter e o setter são usados para acessar e modificar essa lista.   
    public void setConhecimentos(List<String> conhecimentos) {

        this.conhecimentos = conhecimentos;
    }
}