package br.senac.tads.dns.dados_pessoais.entidade;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;
// na set uma etapa 4 pois r
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
// na etapa 4 foi criada a classe PessoaEntity para representar a entidade de pessoa no banco de dados, com os atributos id, username, nome, email, telefone, dataNascimento, senha e conhecimentos. Adicionou as anotações JPA ( @Entity , @Table , @Id , etc.) à classe PessoaEntity
//@Entity — declara que a classe é uma entidade JPA; o Hibernate a mapeia para umatabela no banco de dados
//@Table(name = "...") — opcional; define o nome da tabela. Sem ela, o Hibernate usa o
//nome da classe como nome da tabela
//@Id + @GeneratedValue — define a chave primária com autoincremento
//@Column — personaliza a coluna (nome, tamanho, restrições)
//@ManyToMany + @JoinTable — relacionamento "muitos para muitos", gerenciado por uma
//tabela de junção criada automaticamente pelo Hibernate

// Marca a classe como entidade JPA (vira uma tabela no banco)
@Entity
// Define o nome da tabela
@Table(name = "tb_pessoas")
public class PessoaEntity {

    // Chave primária, gerada pelo banco (autoincrement)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, unique = true, length = 64)
    private String username;

    @Column(nullable = false, length = 100)
    private String nome;

    @Column(nullable = false, length = 100)
    private String email;

    @Column(length = 20)
    private String telefone;

    @Column(name = "data_nascimento")
    private LocalDate dataNascimento;

    @Column(length = 255)
    private String senha;

    // Uma pessoa tem vários conhecimentos, e o mesmo conhecimento
    // pode estar ligado a várias pessoas (muitos para muitos).
    // PERSIST/MERGE: salvar/atualizar a pessoa propaga para os conhecimentos.
    // EAGER: os conhecimentos vêm junto com a pessoa (ok para o exemplo
    // didático, mas pode pesar em projetos reais).
    // REMOVE fica de fora de propósito: ao apagar a pessoa, o Hibernate
    // remove as linhas da tabela de junção sem apagar os conhecimentos.
    @ManyToMany(
            cascade = { CascadeType.PERSIST, CascadeType.MERGE },
            fetch = FetchType.EAGER)
    @JoinTable(
            name = "tb_pessoas_conhecimentos",
            joinColumns = @JoinColumn(name = "pessoa_id"),
            inverseJoinColumns = @JoinColumn(name = "conhecimento_id"))
    private Set<ConhecimentoEntity> conhecimentos = new HashSet<>();

    // Construtor sem argumentos (obrigatório para o JPA)
    public PessoaEntity() {
    }

    public PessoaEntity(Integer id, String username, String nome, String email,
            String telefone, LocalDate dataNascimento, String senha,
            Set<ConhecimentoEntity> conhecimentos) {
        this.id = id;
        this.username = username;
        this.nome = nome;
        this.email = email;
        this.telefone = telefone;
        this.dataNascimento = dataNascimento;
        this.senha = senha;
        this.conhecimentos = conhecimentos;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public Set<ConhecimentoEntity> getConhecimentos() {
        return conhecimentos;
    }

    public void setConhecimentos(Set<ConhecimentoEntity> conhecimentos) {
        this.conhecimentos = conhecimentos;
    }
}