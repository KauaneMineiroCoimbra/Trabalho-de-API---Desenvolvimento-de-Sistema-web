package br.senac.tads.dns.dados_pessoais.segurança;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework. security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation. RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LoginController {

private final AuthenticationManager authenticationManager;
private final JwtService jwtService;
public LoginController(AuthenticationManager authenticationManager, JwtService jwtService) {
this.authenticationManager = authenticationManager;
this.jwtService = jwtService;

}
@PostMapping("/login")
public ResponseEntity <? > login(@RequestBody LoginDto loginDto) {
try {
 Authentication auth = authenticationManager.authenticate(

// Delega a autenticação ao Spring Security.
// Internamente: chama loadUserByUsername() e compara a senha com o encoder.
// Se as credenciais estiverem erradas, lança BadCredentialsException.

new UsernamePasswordAuthenticationToken(
loginDto.getUsername(), loginDto.getSenha()
)
);

// Autenticação bem-sucedida.
// Por enquanto retornamos um token fixo sem significado real.
// Este valor será substituido por um JWT real nos passos 6.6 a 6.8.
UsuarioSistema usuario = (UsuarioSistema) auth.getPrincipal();
// 3. Gera o JWT e retorna ao cliente
String token = jwtService.gerarToken(usuario);
return ResponseEntity.ok(Map.of("token", token));
} catch (BadCredentialsException e) {
// Mensagem genérica - não revela se o problema é o username ou a senha
return ResponseEntity
.status(HttpStatus.UNAUTHORIZED)
.body(Map.of("erro", "Usuário ou senha inválidos"));
}
}
}

//na etapa 6 modificou este codigo para algumas alterações 
//como;JwtService foi injetado no construtor
//authenticationManager.authenticate() agora retorna o objeto Authentication 
// (que antes era ignorado)
//auth.getPrincipal() retorna o UsuarioSistema carregado pelo loadUserByUsername()
//O token retornado é um JWT real assinado, e não mais uma string fixa