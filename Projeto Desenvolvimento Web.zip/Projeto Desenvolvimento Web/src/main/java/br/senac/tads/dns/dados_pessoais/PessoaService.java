package br.senac.tads.dns.dados_pessoais;
// na etapa 5 e criado uma nova pasta
import java.util.List;
import java.util.Optional;

// Contrato: define O QUE o service faz, sem se preocupar com COMO faz
public interface PessoaService {

List<PessoaDto> obterPessoas();

Optional<PessoaDto> obterPessoa(String username);

PessoaDto incluirNovaPessoa(PessoaDto pessoa);

PessoaDto alterarPessoa(String username, PessoaAlteracaoDto pessoaAlteracao);

void removerPessoa(String username);
    //etapa 5 criar a buscarpessoas da interface
List<PessoaDto> buscarPessoas(String termo); // <== NOVO
}