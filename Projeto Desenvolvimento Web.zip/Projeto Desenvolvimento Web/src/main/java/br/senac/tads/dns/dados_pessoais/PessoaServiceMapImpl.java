package br.senac.tads.dns.dados_pessoais;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import jakarta.annotation.PostConstruct;

// Implementação "antiga" do service: guarda as pessoas em memória, num Map.
// Continua existindo, mas o Spring usa a versão JPA (@Primary).
@Service
public class PessoaServiceMapImpl implements PessoaService {

    // Gera ids de forma segura em ambientes concorrentes
    private final AtomicInteger contador = new AtomicInteger(0);

    // Chave: username. Valor: a pessoa. Thread-safe.
    private final Map<String, PessoaDto> mapPessoas = new ConcurrentHashMap<>();

    // Executado logo após o Spring criar o service, antes de qualquer requisição
    @PostConstruct
    public void init() {
        incluirNovaPessoa(new PessoaDto(null, "fulano", "Fulano da Silva",
                "fulano@email.com", "(11) 90000-0001",
                LocalDate.of(1990, 1, 15), "Senha@123", "Senha@123",
                List.of("Java", "SQL")));

        incluirNovaPessoa(new PessoaDto(null, "ciclano", "Ciclano de Souza",
                "ciclano@email.com", "(21) 90000-0002",
                LocalDate.of(1995, 5, 20), "Senha@123", "Senha@123",
                List.of("JavaScript", "React")));

        incluirNovaPessoa(new PessoaDto(null, "beltrana", "Beltrana Lima",
                "beltrana@email.com", "(31) 90000-0003",
                LocalDate.of(2000, 10, 8), "Senha@123", "Senha@123",
                List.of("Spring Boot")));
    }

    @Override
    public List<PessoaDto> obterPessoas() {
        return new ArrayList<>(mapPessoas.values());
    }

    @Override
    public Optional<PessoaDto> obterPessoa(String username) {
        return Optional.ofNullable(mapPessoas.get(username));
    }

    @Override
    public PessoaDto incluirNovaPessoa(PessoaDto pessoa) {
        pessoa.setId(contador.incrementAndGet());

        // putIfAbsent é atômico: retorna null se inseriu,
        // ou a pessoa já existente se o username já estava cadastrado.
        if (mapPessoas.putIfAbsent(pessoa.getUsername(), pessoa) != null) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Username já cadastrado: " + pessoa.getUsername());
        }

        return pessoa;
    }

    

    @Override
    public PessoaDto alterarPessoa(String username, PessoaAlteracaoDto dto) {
        PessoaDto pessoa = mapPessoas.get(username);
        if (pessoa == null) {
            throw new NaoEncontradoException("Pessoa " + username + " não encontrada");
        }

        pessoa.setNome(dto.getNome());
        pessoa.setEmail(dto.getEmail());
        pessoa.setTelefone(dto.getTelefone());
        pessoa.setDataNascimento(dto.getDataNascimento());
        pessoa.setConhecimentos(dto.getConhecimentos());

        return pessoa;
    }

    @Override
    public void removerPessoa(String username) {
        if (mapPessoas.remove(username) == null) {
            throw new NaoEncontradoException("Pessoa " + username + " não encontrada");
        }
    }

    @Override
    public List<PessoaDto> buscarPessoas(String termo) {
       // Deixa o termo em minúsculas para não diferenciar maiúscula de minúscula
        String t = termo.toLowerCase();
        List<PessoaDto> resultado = new ArrayList<>();

        // Percorre todas as pessoas do Map e guarda as que contêm o termo
        // no username, no nome ou no e-mail
        for (PessoaDto p : mapPessoas.values()) {
            if (p.getUsername().toLowerCase().contains(t)
                    || p.getNome().toLowerCase().contains(t)
                    || p.getEmail().toLowerCase().contains(t)) {
                resultado.add(p);
            }
        }
        return resultado;
    
    }
}