package br.senac.tads.dns.dados_pessoais;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import br.senac.tads.dns.dados_pessoais.entidade.ConhecimentoEntity;
import br.senac.tads.dns.dados_pessoais.entidade.PessoaEntity;
import br.senac.tads.dns.dados_pessoais.repositorio.ConhecimentoRepository;
import br.senac.tads.dns.dados_pessoais.repositorio.PessoaRepository;

// Esta classe carrega os dados iniciais no banco assim que a aplicação sobe.
// Como o H2 é um banco em memória, ele começa vazio toda vez que eu rodo o
// projeto. Sem isso, eu teria que cadastrar tudo na mão a cada execução.
//
// @Component: o Spring cria um objeto desta classe sozinho.
// CommandLineRunner: o Spring chama o método run() uma vez, logo depois
// que a aplicação termina de iniciar.
// Executa ao subir a aplicação e carrega os dados iniciais no banco
@Component
public class DataInitializer implements CommandLineRunner {
// Os repositórios são o meu acesso ao banco de dados.
    private final PessoaRepository pessoaRepository;
    private final ConhecimentoRepository conhecimentoRepository;

//etapa 4 
     // O Spring entrega os dois repositórios prontos pelo construtor
    // (injeção de dependência), sem eu precisar dar "new" neles.
    public DataInitializer(PessoaRepository pessoaRepository,
            ConhecimentoRepository conhecimentoRepository) {
        this.pessoaRepository = pessoaRepository;
        this.conhecimentoRepository = conhecimentoRepository;
    }
// @Transactional: tudo o que acontece dentro do run() vale como uma
    // transação só. Se der erro no meio, o banco desfaz tudo (rollback) e
    // não fica com dados pela metade.
    @Override
    @Transactional
    public void run(String... args) throws Exception {
        List<String> conhecimentos = List.of("Java", "Javascript", "SQL",
                "HTML", "CSS", "Docker", "Angular", "React");
        
        // Mapa "nome -> entidade". Vou usar para achar rápido o conhecimento
        // certo na hora de ligar cada pessoa aos seus conhecimentos.
        
                Map<String, ConhecimentoEntity> mapConhecimentos = new HashMap<>();
  // 1. CONHECIMENTOS: só cria se a tabela estiver vazia.
        // 1. Pré-popula a tabela de conhecimentos (somente se estiver vazia)
        if (conhecimentoRepository.count() == 0) {



// Para cada nome da lista, crio uma ConhecimentoEntity nova
            // (ainda não está no banco) e guardo no mapa.

            for (var c : conhecimentos) {
                ConhecimentoEntity cEnt = new ConhecimentoEntity();
                cEnt.setNome(c);
                mapConhecimentos.put(c, cEnt);
            }
// saveAll grava todos de uma vez na tabela tb_conhecimentos.
            // O banco gera o id de cada um (IDENTITY) e o id volta
            // para os mesmos objetos que estão dentro do mapa.


            conhecimentoRepository.saveAll(mapConhecimentos.values());
        } else {
            mapConhecimentos = conhecimentoRepository.findAll().stream()
                    .collect(Collectors.toMap(ConhecimentoEntity::getNome,
                            Function.identity()));
        }
// Se a tabela já tem dados, não crio de novo (o nome é unique e
            // daria erro). Em vez disso, leio tudo do banco e monto o mapa
            // "nome -> entidade" a partir dos registros que já existem.
            // Function.identity() significa "o valor do mapa é o próprio objeto".

        // 2. Pré-popula as pessoas (somente se a tabela estiver vazia)
        if (pessoaRepository.count() == 0) {
            PessoaEntity p1 = new PessoaEntity();

 // Pessoa 1: monto o objeto com os setters (ele ainda não está no banco).   
            p1.setUsername("jpinkman");
            p1.setNome("Jesse Pinkman");
            p1.setEmail("jpinkman@email.com");
            p1.setTelefone("(11) 99000-9999");
            p1.setDataNascimento(LocalDate.parse("2000-10-20"));
   // A senha está em texto puro porque é só um exemplo didático.
   
  // Ligo a pessoa aos conhecimentos, pegando do mapa os que já
            // foram salvos. É isso que cria o relacionamento muitos-para-muitos.
            
            
            p1.setSenha("Abcd%12345");
            p1.getConhecimentos().add(mapConhecimentos.get("Java"));
            p1.getConhecimentos().add(mapConhecimentos.get("SQL"));
            p1.getConhecimentos().add(mapConhecimentos.get("Docker"));
            pessoaRepository.save(p1);

            PessoaEntity p2 = new PessoaEntity();
            p2.setUsername("ironman");
            p2.setNome("Tony Stark");
            p2.setEmail("ironman@email.com");
            p2.setTelefone("(21) 98000-8888");
            p2.setDataNascimento(LocalDate.parse("1999-05-10"));
            p2.setSenha("Abcd%12345");
            p2.getConhecimentos().add(mapConhecimentos.get("Angular"));
            p2.getConhecimentos().add(mapConhecimentos.get("Javascript"));
            p2.getConhecimentos().add(mapConhecimentos.get("HTML"));
            p2.getConhecimentos().add(mapConhecimentos.get("CSS"));
            pessoaRepository.save(p2);

            PessoaEntity p3 = new PessoaEntity();
            p3.setUsername("eleven");
            p3.setNome("Eleven Hopper");
            p3.setEmail("eleven@email.com");
            p3.setTelefone("(31) 97000-7777");
            p3.setDataNascimento(LocalDate.parse("2001-02-23"));
            p3.setSenha("Abcd%12345");
            p3.getConhecimentos().add(mapConhecimentos.get("Java"));
            p3.getConhecimentos().add(mapConhecimentos.get("React"));
            p3.getConhecimentos().add(mapConhecimentos.get("SQL"));
            pessoaRepository.save(p3);
        }
    }
}