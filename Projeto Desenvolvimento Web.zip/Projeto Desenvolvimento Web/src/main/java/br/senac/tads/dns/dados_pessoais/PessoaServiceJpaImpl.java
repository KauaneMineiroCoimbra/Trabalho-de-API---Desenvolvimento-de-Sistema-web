package br.senac.tads.dns.dados_pessoais;

import java.util.List;
import java.util.Optional;

import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import br.senac.tads.dns.dados_pessoais.entidade.ConhecimentoEntity;
import br.senac.tads.dns.dados_pessoais.entidade.PessoaEntity;
import br.senac.tads.dns.dados_pessoais.repositorio.ConhecimentoRepository;
import br.senac.tads.dns.dados_pessoais.repositorio.PessoaRepository;

// @Primary: quando há mais de uma implementação de PessoaService,
// o Spring injeta ESTA por padrão (sem precisar alterar o controller)
@Primary
@Service
public class PessoaServiceJpaImpl implements PessoaService {

    private final PessoaRepository pessoaRepository;
    private final ConhecimentoRepository conhecimentoRepository;

    public PessoaServiceJpaImpl(PessoaRepository pessoaRepository,
            ConhecimentoRepository conhecimentoRepository) {
        this.pessoaRepository = pessoaRepository;
        this.conhecimentoRepository = conhecimentoRepository;
    }

    // ---- Métodos auxiliares: conversão entre Entity e DTO ----

    // PessoaEntity -> PessoaDto
    private PessoaDto toDto(PessoaEntity entity) {
        PessoaDto dto = new PessoaDto();
        dto.setId(entity.getId());
        dto.setUsername(entity.getUsername());
        dto.setNome(entity.getNome());
        dto.setEmail(entity.getEmail());
        dto.setTelefone(entity.getTelefone());
        dto.setDataNascimento(entity.getDataNascimento());

        // A.1: extrai só o nome de cada ConhecimentoEntity, com stream
        List<String> nomes = entity.getConhecimentos().stream()
                .map(ConhecimentoEntity::getNome)
                .toList();
        dto.setConhecimentos(nomes);

        return dto;
    }

    // PessoaDto -> PessoaEntity (para inserção: sem ID, o banco gera)
    private PessoaEntity toEntity(PessoaDto dto) {
        PessoaEntity entity = new PessoaEntity();
        entity.setUsername(dto.getUsername());
        entity.setNome(dto.getNome());
        entity.setEmail(dto.getEmail());
        entity.setTelefone(dto.getTelefone());
        entity.setDataNascimento(dto.getDataNascimento());
        entity.setSenha(dto.getSenha());

        // Reaproveita os conhecimentos que já existem no banco
        if (dto.getConhecimentos() != null) {
            for (String nomeConhecimento : dto.getConhecimentos()) {
                Optional<ConhecimentoEntity> optConh = conhecimentoRepository
                        .findByNomeIgnoreCase(nomeConhecimento);
                if (optConh.isPresent()) {
                    entity.getConhecimentos().add(optConh.get());
                }
            }
        }
        return entity;
    }

    // ---- Implementação do contrato, usando os Repositories ----

    @Override
    @Transactional(readOnly = true) // readOnly: otimiza leituras
    public List<PessoaDto> obterPessoas() {
        // A.1: aplica toDto() em cada entidade e coleta numa List
        return pessoaRepository.findAll()
                .stream()
                .map(this::toDto)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<PessoaDto> buscarPessoas(String termo) {
        // Mesmo padrão do A.1, agora sobre o resultado da busca
        return pessoaRepository.buscarPorTermo(termo)
                .stream()
                .map(this::toDto)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<PessoaDto> obterPessoa(String username) {
        // A.2: se achou, converte para DTO; se não achou, devolve Optional vazio
        return pessoaRepository.findByUsername(username)
                .map(this::toDto);
    }

    @Override
    @Transactional
    public PessoaDto incluirNovaPessoa(PessoaDto dto) {
        // Username repetido: devolve 409, como a versão em Map fazia
        if (pessoaRepository.existsByUsername(dto.getUsername())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Username já cadastrado: " + dto.getUsername());
        }

        PessoaEntity entity = toEntity(dto);
        PessoaEntity salva = pessoaRepository.save(entity); // INSERT
        return toDto(salva); // devolve com o ID gerado pelo banco
    }

    @Override
    @Transactional
    public PessoaDto alterarPessoa(String username, PessoaAlteracaoDto pessoaAlteracao) {
        // A.3: busca a entidade; se não existir, lança NaoEncontradoException
        PessoaEntity entity = pessoaRepository.findByUsername(username)
                .orElseThrow(() -> new NaoEncontradoException(
                        "Pessoa " + username + " não encontrada"));

        // Atualiza os campos simples
        entity.setNome(pessoaAlteracao.getNome());
        entity.setEmail(pessoaAlteracao.getEmail());
        entity.setTelefone(pessoaAlteracao.getTelefone());
        entity.setDataNascimento(pessoaAlteracao.getDataNascimento());

        // Atualiza os conhecimentos:
        // 1. Limpa a lista atual (remove as linhas de tb_pessoas_conhecimentos)
        entity.getConhecimentos().clear();
        // 2. Adiciona os novos, reutilizando as entidades que já existem
        if (pessoaAlteracao.getConhecimentos() != null) {
            for (String nomeConhecimento : pessoaAlteracao.getConhecimentos()) {
                Optional<ConhecimentoEntity> optConh = conhecimentoRepository
                        .findByNomeIgnoreCase(nomeConhecimento);
                if (optConh.isPresent()) {
                    entity.getConhecimentos().add(optConh.get());
                }
            }
        }

        PessoaEntity salva = pessoaRepository.save(entity); // UPDATE
        return toDto(salva);
    }

    @Override
    @Transactional
    public void removerPessoa(String username) {
        // A.3: mesma ideia do alterarPessoa
        PessoaEntity entity = pessoaRepository.findByUsername(username)
                .orElseThrow(() -> new NaoEncontradoException( "Pessoa " + username + " não encontrada"));

        // DELETE: remove a pessoa e as linhas dela na tabela de junção.
        // Os conhecimentos continuam no banco (não há cascade REMOVE).
        pessoaRepository.delete(entity);
    }
}