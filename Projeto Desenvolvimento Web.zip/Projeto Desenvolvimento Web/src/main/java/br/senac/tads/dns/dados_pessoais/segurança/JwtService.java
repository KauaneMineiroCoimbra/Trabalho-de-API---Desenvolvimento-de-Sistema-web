package br.senac.tads.dns.dados_pessoais.segurança;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time. Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
// na etapa 6 desenvolvendo a parte da classe java de service 
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core. GrantedAuthority;
import org.springframework.stereotype.Service;
// Segredo usado na assinatura (application.properties)
import com.nimbusds.jose. JOSEException;
import com.nimbusds.jose. JWSAlgorithm;
import com.nimbusds.jose. JWSHeader;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jwt.JWT;
import com.nimbusds.jwt. JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

@Service
public class JwtService {
// Validade do token em segundos (padrão: 1 hora)
@Value("${jwt.secret}")
private String jwtSecret;
// Authorities -> lista de Strings (ex: ["ROLE_ADMIN"])
@Value("${jwt.expiracao-segundos: 3600}")
private long expiracaoSegundos;
// Payload do token

// Gera um JWT a partir dos dados do usuário autenticado.
// Monta as claims e delega a assinatura para jwtEncode().

public String gerarToken(UsuarioSistema usuario) {
// Converte as authorities para uma lista de Strings (ex: ["ROLE_ADMIN", "ROLE_USER"])
List<String> roles = new ArrayList<>();
for (GrantedAuthority authority : usuario.getAuthorities()) {
roles.add(authority.getAuthority());
}
Instant agora = Instant.now();
Instant expiracao = agora.plusSeconds (expiracaoSegundos);
// JWTClaimsSet representa o payload do token - o conjunto de "claims" (afirmações)
JWTClaimsSet claims = new JWTClaimsSet.Builder()
.subject(usuario.getUsername())
.issuer("dados-pessoais-api")
.issueTime(Date.from(agora))
.expirationTime(Date. from(expiracao))
.claim("roles", roles)
.build();

return jwtEncode(claims);
}
// "sub": identifica o usuário
// "iss": quem emitiu o token
// "iat": timestamp de emissão (issued at)
// "exp": timestamp de expiração
// claim customizado com as roles do usuário
//Assina um JWTClaimsSet e serializa o resultado no formato "header.payload.signature".
// Separar esta lógica de gerarToken() permite reutilizá-la para outros tipos de token
//  (ex: refresh token) sem duplicar a lógica de assinatura.

private String jwtEncode(JWTClaimsSet claims) {
try {
// 1. Deriva uma chave de 256 bits a partir da string secreta usando SHA-256.
// Isso permite usar qualquer string como segredo, independente do comprimento.
byte[] keyBytes = MessageDigest.getInstance("SHA-256")
.digest(jwtSecret.getBytes(StandardCharsets.UTF_8));
MACSigner signer = new MACSigner(keyBytes);

// 2. Cria o JWT combinando o header (algoritmo) com o payload (claims)
SignedJWT jwt = new SignedJWT(
new JWSHeader(JWSAlgorithm.HS256), // HS256 = HMAC-SHA256
claims

);
// 3. Assina com a chave secreta - gera a terceira parte do token
jwt.sign(signer);

// 4. Serializa para a String final: "header.payload.signature"
return jwt.serialize();

} catch (JOSEException | NoSuchAlgorithmException e) {
throw new RuntimeException("Erro ao assinar token JWT", e);

}
}
}

/// sub: usuário       // iss: emissor
	// iat: emissão
 // exp: expiração
     // perfis do usuário
     /** Assina as claims e serializa como "header.payload.signature". */
// Chave de 256 bits derivada do segredo via SHA-256