package br.senac.tads.dns.dados_pessoais;

//o net uri e um pacote que fornece classes para manipular URIs (Uniform Resource Identifiers), enquanto o util list e um pacote que fornece
//  a interface List, que é usada para representar uma lista de objetos.
import java.net.URI;
import java.util.List;

import org.springframework.http.HttpStatus;

//na etapa 4 e criado o problemdetail que é uma classe que representa um problema de requisição HTTP, com os atributos status e detail. Ele é usado para retornar uma resposta HTTP com o código de status e a mensagem de erro apropriados quando uma exceção é lançada.
//nela implementa erros
import org.springframework.http.ProblemDetail;
// aqui ele inicializa o pacote httpstatus que fornece códigos de status HTTP, como 404 (Not Found) e 500 (Internal Server Error),
//  que são usados para indicar o resultado de uma requisição HTTP.
import org.springframework.http.ResponseEntity;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

// o requestMappig faz a anotação, para maquear a classe como um controlador REST, que lida com requisições HTTP e retorna respostas HTTP.
//o path atual é usado para mapear o caminho base para todos os métodos do controlador, que é /pessoas neste caso.
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
// o servleturi e um pacote que fornece classes para construir URIs (Uniform Resource Identifiers) a partir de informações da requisição 
// HTTP atual, como o caminho do contexto e os parâmetros da query string.
import jakarta.validation.Valid;

// aaui faz a validacao dos dados recebidos no corpo da requisição HTTP, garantindo que eles atendam aos requisitos definidos na classe Pessoa, como campos obrigatórios e tamanho máximo.
// a validacao que fiz uma pasta com os validadores personalizados, como a anotação @SenhasIguais, que valida se as senhas informadas são iguais.
@RestController
@RequestMapping("/pessoas")
public class PessoaController {
//atualizando o nome da etapa 5 
    private final PessoaService pessoaService;

    public PessoaController(PessoaService pessoaService) {
        this.pessoaService = pessoaService;
    }

    // GET /pessoas
    // o get e o metodo p obter a lista de pessoas cadastradas no sistema, que é
    // retornada como uma lista de objetos Pessoa.
    // get = busca a lista de pessoas cadastradas no sistema, que é retornada como
    // uma lista de objetos Pessoa.
    @GetMapping
    public List<PessoaDto> obterPessoas() {
        return pessoaService.obterPessoas();
    }

    //etapa 5 -criar novo 
// GET /pessoas/busca?q=<termo>
@GetMapping("/busca")
public ResponseEntity<List<PessoaDto>> buscarPessoas(@RequestParam("q") String termo) {
 return ResponseEntity.ok(pessoaService.buscarPessoas(termo));
}

    // GET /pessoas/{username}
    // aqui ele faz a busca de uma pessoa pelo username, que é passado como
    // parâmetro na URL. Se a pessoa não for encontrada, ele lança uma exceção com o
    // código de status HTTP 404 (Not Found).
    // get = busca uma pessoa pelo username, que é passado como parâmetro na URL.
    @GetMapping("/{username}")
    public PessoaDto obterPessoa(@PathVariable String username) {
        return pessoaService.obterPessoa(username)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    }

    // POST /pessoas/sem-validacao (didático: SEM @Valid de propósito)
    // o post atualiza a lista de pessoas cadastradas no sistema, adicionando uma
    // nova pessoa.
    // O corpo da requisição HTTP deve conter um objeto Pessoa em formato JSON.

    // post = atualiza a lista de pessoas cadastradas no sistema, adicionando uma
    // nova pessoa.
    @PostMapping("/sem-validacao")
    public ResponseEntity<Void> incluirNovoSemValidacao(@RequestBody PessoaDto pessoa) {
        pessoaService.incluirNovaPessoa(pessoa);
        // a pessoa justamente é adicionada na lista de pessoas cadastradas no sistema,
        // e o código de status HTTP 201 (Created) é retornado,
        // junto com a URI da nova pessoa criada como cabeçalho da resposta HTTP. A URI
        // é construída a partir do caminho base /pessoas e do username da nova pessoa
        // criada.
        URI location = ServletUriComponentsBuilder

                // o servleturicomponentsbuilder é usado para construir a URI da nova pessoa
                // criada, a partir do caminho base /pessoas e do username da nova pessoa
                // criada.
                .fromCurrentContextPath()
                .path("/pessoas/{username}")
                .buildAndExpand(pessoa.getUsername())
                .toUri();
        // o path faz com que o caminho base /pessoas seja concatenado com o username da
        // nova pessoa criada, formando a URI completa da nova pessoa criada.
        return ResponseEntity.created(location).build();
    }

    // POST /pessoas (COM validação)
    // o post atualiza a lista de pessoas cadastradas no sistema, adicionando uma
    // nova pessoa. O corpo da requisição HTTP deve conter um objeto Pessoa em
    // formato JSON.
    // A anotação @Valid faz com que o Spring Boot valide automaticamente os dados
    // recebido no http.
    @PostMapping
    public ResponseEntity<Void> incluirNovo(@RequestBody @Valid PessoaDto pessoa) {
        pessoaService.incluirNovaPessoa(pessoa);

        URI location = ServletUriComponentsBuilder
                .fromCurrentContextPath()
                .path("/pessoas/{username}")
                .buildAndExpand(pessoa.getUsername())
                .toUri();
        // o created cria o código de status HTTP 201 (Created) e adiciona a URI da nova
        // pessoa criada como cabeçalho da resposta HTTP.
        return ResponseEntity.created(location).build();
    }

    @PutMapping("/{username}")

    //na etapa 4- Adicionou o método alterarPessoa() ao PessoaService e o endpoint PUT /pessoas/{username} ao controller — e observou que sem validação o servidor aceita dados incorretos

    //Criou o endpoint POST /pessoas com @Valid , que rejeita automaticamente dados inválidos com HTTP 400

    public PessoaDto alterarPessoa(@PathVariable String username,
            @Valid @RequestBody PessoaAlteracaoDto dto) {
        return pessoaService.alterarPessoa(username, dto);
    }

    @DeleteMapping("/{username}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void removerPessoa(@PathVariable String username) {
        pessoaService.removerPessoa(username);
    }

    @ExceptionHandler(NaoEncontradoException.class)
    public ProblemDetail tratarNaoEncontrado(NaoEncontradoException ex) {
        return ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, ex.getMessage());
    }
}