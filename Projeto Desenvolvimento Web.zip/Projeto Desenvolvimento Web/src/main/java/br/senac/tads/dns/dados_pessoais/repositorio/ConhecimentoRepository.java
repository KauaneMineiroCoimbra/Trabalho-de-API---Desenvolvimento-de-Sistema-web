package br.senac.tads.dns.dados_pessoais.repositorio;
// na etapa 4 foi criada a interface ConhecimentoRepository para definir os métodos de acesso ao banco de dados para a entidade ConhecimentoEntity.
//  Ela estende JpaRepository, que fornece métodos CRUD prontos, e adiciona o método personalizado findByNomeIgnoreCase para buscar um conhecimento pelo nome, ignorando maiúsculas e minúsculas.

// a etapa 4 e fundamental para a criação da interface ConhecimentoRepository, que estende JpaRepository, permitindo realizar operações CRUD na entidade ConhecimentoEntity.
//  Além disso, foi adicionado o método personalizado findByNomeIgnoreCase para buscar um conhecimento pelo nome, ignorando maiúsculas e minúsculas.
import java.util.Optional;

import org.springframework.data.jpa.repository. JpaRepository;
import org.springframework.stereotype. Repository;

import br.senac.tads.dns.dados_pessoais.entidade.ConhecimentoEntity;

@Repository
public interface ConhecimentoRepository extends JpaRepository<ConhecimentoEntity, Integer> {

// Gera: SELECT * FROM tb_conhecimentos WHERE LOWER(nome) = LOWER(:nome)
// Usado para reutilizar um conhecimento já existente (sem distinção de maiúsculas)
Optional<ConhecimentoEntity> findByNomeIgnoreCase(String nome);
}


//findBy: busca registros. Nome: filtra pelo campo nome da ConhecimentoEntity.
//IgnoreCase: compara sem diferenciar maiúsculas de minúsculas. “java”, “Java” e “JAVA” são o mesmo conhecimento.