package br.senac.tads.dns.dados_pessoais.entidade;
// na etapa 4.3- crie a classe ConhecimentoEntity para representar a entidade de conhecimento no banco de dados, com os atributos id e nome. Adicione as anotações JPA ( @Entity , @Table , @Id , etc.) à classe ConhecimentoEntity

import jakarta.persistence.Column;
//ele cria para que o nome do conhecimento seja armazenado em uma coluna da tabela tb_conhecimentos, com as restrições de não nulo, único e tamanho máximo de 100 caracteres.
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
// o entity é usado para indicar que a classe ConhecimentoEntity é uma entidade JPA, que será mapeada para uma tabela no banco de dados. O table é usado para definir o nome da tabela como tb_conhecimentos. O id é usado para indicar que o atributo id é a chave primária da tabela, e o generatedvalue é usado para definir a estratégia de geração do valor do id como identity, ou seja, o banco de dados vai gerar automaticamente um valor único para cada registro inserido na tabela.

//na etapa 4 ewle faz com que a classe ConhecimentoEntity seja usada para mapear os conhecimentos de uma pessoa no banco de dados, permitindo que cada conhecimento seja armazenado em uma tabela separada, com um id único e um nome. Isso facilita a manipulação dos dados e a criação de relacionamentos entre as entidades Pessoa e ConhecimentoEntity.
//ele faz o funcionamento do spring boot para criar a tabela tb_conhecimentos no banco de dados, com as colunas id e nome, e para mapear os objetos da classe ConhecimentoEntity para os registros da tabela. Ele também permite que o Spring Data JPA gere automaticamente as consultas SQL para inserir, atualizar, excluir e buscar os conhecimentos no banco de dados.

@Entity
@Table(name = "tb_conhecimentos")
public class ConhecimentoEntity {

//
// LEMBRE-SE: gere os getters, setters e o construtor sem argumentos
// (obrigatório no JPA) para todos os campos desta classe.

// aqui gera os getters e setters para os atributos id e nome, permitindo que eles sejam acessados e modificados de forma controlada. O construtor sem argumentos é necessário para que o JPA possa criar instâncias da entidade ConhecimentoEntity quando estiver carregando dados do banco de dados. O JPA usa reflexão para instanciar objetos e precisa de um construtor público ou protegido sem argumentos para isso.
//na etapa 4.3- crie a classe ConhecimentoEntity para representar a entidade de conhecimento no banco de dados, com os atributos id e nome. Adicione as anotações JPA ( @Entity , @Table , @Id , etc.) à classe ConhecimentoEntity
@Id
@GeneratedValue(strategy = GenerationType. IDENTITY)
private Integer id;

public Integer getId() {
    return id;
}
// o contrutor sem argumentos é necessário para que o JPA possa criar instâncias da entidade ConhecimentoEntity quando estiver carregando dados do banco de dados. O JPA usa reflexão para instanciar objetos e precisa de um construtor público ou protegido sem argumentos para isso.
//na etapa proxima 
//    public ConhecimentoEntity(Integer id, String nome) {
        //this.id = id;
       // this.nome = nome;
  //  }


public ConhecimentoEntity() {
   
}

public void setId(Integer id) {
    this.id = id;
}

public String getNome() {
    return nome;
}

public void setNome(String nome) {
    this.nome = nome;
}

@Column(nullable = false, unique = true, length = 100)
private String nome;
}


