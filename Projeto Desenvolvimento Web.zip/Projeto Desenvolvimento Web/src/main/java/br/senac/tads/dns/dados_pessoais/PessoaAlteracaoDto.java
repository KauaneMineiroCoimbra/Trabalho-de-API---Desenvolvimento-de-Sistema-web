package br.senac.tads.dns.dados_pessoais;

import java.time.LocalDate;
import java.util.List;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Size;
// NA ETAPA 4- Criou a classe PessoaAlteracaoDto para representar os dados de alteração de uma pessoa, com os atributos nome, email, telefone, dataNascimento e conhecimentos. Adicionou as anotações Bean Validation ( @NotBlank , @Email , @PastOrPresent , etc.) à classe PessoaAlteracaoDto

// A classe PessoaAlteracaoDto é usada para receber os dados de alteração de uma pessoa no endpoint PUT /pessoas/{username}. Ela possui um construtor vazio, getters e setters para os atributos, e as anotações Bean Validation para validar os dados recebidos.
//Criou NaoEncontradoException e PessoaAlteracaoDto (campos editáveis sem username/senha)
public class PessoaAlteracaoDto {

    @NotBlank(message = "O nome completo é obrigatório")
    @Size(max = 100)
    private String nome;

    @NotBlank
    @Size(max = 100)
    @Email
    private String email;

    @Size(max = 20)
    private String telefone;

    @NotNull
    @PastOrPresent
    private LocalDate dataNascimento;

    private List<String> conhecimentos;

    public PessoaAlteracaoDto() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public List<String> getConhecimentos() {
        return conhecimentos;
    }

    public void setConhecimentos(List<String> conhecimentos) {
        this.conhecimentos = conhecimentos;
    }
}