package br.senac.tads.dns.dados_pessoais;

//o package do mensagem faz com que defina o pacote onde a classe Mensagem está localizada, que é br.senac.tads.dns.dados_pessoais.
public class Mensagem  {
	private String nome;
	private String texto;
	public Mensagem(String nome, String texto) {
		this.nome = nome;
		this.texto = texto;
	}
	public String getNome() { return nome; }
	public String getTexto() { return texto; }
}

//oq representa uma mensagem com um nome e um texto. Ela possui um construtor que recebe o nome e o texto como parâmetros, e dois métodos
//  getters para acessar esses valores.

//oq acontece aqui é que a classe Mensagem é usada para criar objetos que representam mensagens com um nome e um texto. Esses objetos podem ser
//  retornados como resposta de endpoints REST, e o Spring Boot vai serializar automaticamente esses objetos em JSON, sem a necessidade de usar o ObjectMapper manualmente.