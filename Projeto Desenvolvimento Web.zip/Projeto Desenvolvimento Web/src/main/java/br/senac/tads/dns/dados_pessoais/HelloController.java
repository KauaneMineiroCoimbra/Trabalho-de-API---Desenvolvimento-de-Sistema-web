package br.senac.tads.dns.dados_pessoais;
// o package define a pasta onde a classe HelloController está localizada, que é br.senac.tads.dns.dados_pessoais.
import tools.jackson.core.JacksonException;
import tools.jackson.databind.ObjectMapper;
// o import importa a classe ObjectMapper da biblioteca Jackson, que é usada para converter objetos Java em JSON e vice-versa.

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
// o get do mapping é usado para mapear requisições HTTP GET para métodos específicos do controlador, enquanto o restcontroller 
// é usado para indicar que a classe é um controlador REST, que retorna dados em formato JSON.
 //com o restcontroller, o Spring Boot vai serializar automaticamente os objetos retornados pelos métodos em JSON, sem a necessidade de usar o ObjectMapper manualmente.
@RestController

public class HelloController {
// a classe publica retorna um objeto Mensagem, enquanto o segundo retorna uma string JSON gerada manualmente com o ObjectMapper.
	@GetMapping("/hello")
	public Mensagem hello() {
		return new Mensagem(
			"Kauane Mineiro Coimbra",
			"Olá, mundo! Meu primeiro endpoint Spring Boot."
		);
	}
// aqui e onde o json é gerado manualmente com o ObjectMapper, que é uma classe da biblioteca Jackson usada para converter objetos Java em JSON e vice-versa.
	@GetMapping(value = "/hello-manual", produces = MediaType.APPLICATION_JSON_VALUE)
	public String helloManual() throws JacksonException {
		Mensagem mensagem = new Mensagem(
			"Kauane Mineiro Coimbra",
			"JSON gerado manualmente com ObjectMapper."
		);

		ObjectMapper mapper = new ObjectMapper();
// com o objectMapper, o Spring Boot vai serializar automaticamente os objetos retornados pelos métodos em JSON, sem a necessidade de usar o ObjectMapper manualmente.
		return mapper.writeValueAsString(mensagem);
	}
}
// o return mapper.writeValueAsString(mensagem); ele vai converter o objeto Mensagem em uma string JSON, que é retornada como resposta da requisição HTTP GET para o endpoint /hello-manual.
// o mapper e um objeto da classe ObjectMapper, que é usado para converter objetos Java em JSON e vice-versa. O método writeValueAsString() é usado para converter o objeto Mensagem em uma string JSON.
// ele faz com que o Spring Boot serializa automaticamente os objetos retornados pelos métodos em JSON, sem a necessidade de usar o ObjectMapper manualmente.

