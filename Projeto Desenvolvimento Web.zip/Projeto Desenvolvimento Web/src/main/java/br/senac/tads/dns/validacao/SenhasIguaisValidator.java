package br.senac.tads.dns.validacao;

import org.springframework.stereotype.Component;

import br.senac.tads.dns.dados_pessoais.PessoaDto;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
// o validadorContext e usado para fornecer informações sobre a validação em andamento, como o objeto que está sendo validado, 
// o valor do campo que está sendo validado, e permitindo adicionar mensagens de erro personalizadas para o campo ou para a classe como um todo.
@Component
public class SenhasIguaisValidator
        implements ConstraintValidator<SenhasIguais, PessoaDto> {

    private String mensagem;
//o private String mensagem é usado para armazenar a mensagem de erro que será exibida caso a validação falhe.
    @Override
    public void initialize(SenhasIguais annotation) {
        // a inicializar usado para o validador, que é chamado quando a anotação @SenhasIguais é aplicada a uma classe recebendo como parâmetro 
        // a anotação @SenhasIguais, que contém a mensagem de erro configurada pelo desenvolvedor.
        // Lê a mensagem configurada na anotação @SenhasIguais
        this.mensagem = annotation.message();
    }
// o isValid é usado para validar se as senhas informadas em um objeto Pessoa são iguais, retornando true se forem iguais e false caso contrário.
//o override  sobrescreve o método isValid da interface ConstraintValidator, que é chamado pelo framework de validação para validar o objeto Pessoa.
    @Override
    public boolean isValid(PessoaDto pessoa, ConstraintValidatorContext context) {
        boolean resultado = pessoa.getSenha() != null &&
                pessoa.getSenha().equals(pessoa.getSenhaRepeticao());
        if (!resultado) {

    // Associa o erro ao campo "senha" em vez de à classe toda, 
    // para que a mensagem de erro seja exibida junto ao campo correto no formulário. o disable e usado para desabilitar a mensagem de erro padrão,
    //  e o iolationWithTemplate é usado para construir uma nova mensagem de erro personalizada, associando-a ao campo "senha" do objeto Pessoa.
            context.disableDefaultConstraintViolation(); // o disable e feito para desabilitar a mensagem de erro padrão, 
            // constraint é usado para construir uma nova mensagem de erro personalizada, associando-a ao campo "senha" do objeto Pessoa.
            context.buildConstraintViolationWithTemplate(mensagem) // add o template da mensagem de erro
                    .addPropertyNode("senha").addConstraintViolation(); //add prioridade de erro ao campo "senha"
        }
        return resultado; //retorna resultado da validação, que é true se as senhas forem iguais e false caso contrário. 
    }
}
